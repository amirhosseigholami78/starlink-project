const element = document.querySelector(".starlink_menu_link");
function _changeColor() {
//   2. Modify its custom css properties
  element.style.setProperty("--check-show", "flex");
}

function opne_mon_menu(){
    document.getElementsByClassName('mobile_menu')[0].style.right = '0%'
}
function close_mon_menu(){
    document.getElementsByClassName('mobile_menu')[0].style.right = '-100%'
}

// end header section 
let slides = document.querySelectorAll('.slide-container');
let index = 0;

function next(){
    slides[index].classList.remove('active');
    index = (index + 1) % slides.length;
    slides[index].classList.add('active');
}

function prev(){
    slides[index].classList.remove('active');
    index = (index - 1 + slides.length) % slides.length
    slides[index].classList.add('active');
}
// ens slider section 

ScrollReveal({ reset: false,
    // if enter true instead of false for this method, every single time no matter if you refresh or not, whenever the scroll comes to an element, the elemet will start showning all over again. so it's up to you to choose what you want among those two input
  distance: '60px',
  duration: 2500,
  delay: 400 
});
ScrollReveal().reveal('.head_top_menu',{ delay: 500, origin: 'left' });
ScrollReveal().reveal('.order, .High',  { delay: 600, origin: 'bottom' });
ScrollReveal().reveal('.myform', { delay: 700, origin: 'top' });
ScrollReveal().reveal('.sub_stream_1', { delay: 500, origin: 'bottom', interval: 200 });
ScrollReveal().reveal('.sub_stream_2 ', { delay: 500, origin: 'top'});
ScrollReveal().reveal('.optim_slider', { delay: 500, origin: 'right'});
ScrollReveal().reveal('.CUSTOMER', { delay: 500, origin: 'left', interval: 200 });
ScrollReveal().reveal('.Try', { delay: 500, origin: 'right', interval: 200 });
ScrollReveal().reveal('.myfooter', { delay: 500, origin: 'left', interval: 200 });